library(forecast)
library(ggplot2)
library(dplyr)
library(lubridate)
library(plotly)

# Assuming file is in your Downloads
path_to_file <- list.files(path = "~/Downloads/ADSP_31006_FinalProject", pattern = "elec_data_clean.csv", full.names = TRUE)

elec_data_clean <- read.csv(path_to_file)
elec_data_clean$date <- ymd(elec_data_clean$date)
elec_data_clean <- elec_data_clean %>% arrange(date)

# Comment if using auto.arima
#min_constant = 76
#elec_data_clean$Consumption <- elec_data_clean$Consumption + min_constant

# Aggregate by day
elec_data_daily <- elec_data_clean %>%
  group_by(date) %>%
  summarise(Consumption = mean(Consumption))

# Aggregate by week
elec_data_weekly <- elec_data_clean %>%
  mutate(week = floor_date(date, "week")) %>%
  group_by(week) %>%
  summarise(Consumption = mean(Consumption))

# Aggregate by month
elec_data_monthly <- elec_data_clean %>%
  mutate(month = floor_date(date, "month")) %>%
  group_by(month) %>%
  summarise(Consumption = mean(Consumption))

train_test_split_date <- as.Date("2023-03-31")
train_set_daily <- elec_data_daily %>% filter(date <= train_test_split_date)
test_set_daily <- elec_data_daily %>% filter(date > train_test_split_date)

train_set_weekly <- elec_data_weekly %>% filter(week <= train_test_split_date)
test_set_weekly <- elec_data_weekly %>% filter(week > train_test_split_date)

train_set_monthly <- elec_data_monthly %>% filter(month <= train_test_split_date)
test_set_monthly <- elec_data_monthly %>% filter(month > train_test_split_date)

train_elec_cons_daily <- ts(train_set_daily$Consumption, frequency = 365, start = c(year(min(train_set_daily$date)), yday(min(train_set_daily$date))))
train_elec_cons_weekly <- ts(train_set_weekly$Consumption, frequency = 52, start = c(year(min(train_set_weekly$week)), week(min(train_set_weekly$week))))
train_elec_cons_monthly <- ts(train_set_monthly$Consumption, frequency = 12, start = c(year(min(train_set_monthly$month)), month(min(train_set_monthly$month))))

# Change this when you want to do SArima / auto.arima 
# ar_fit_daily <- auto.arima(train_elec_cons_daily)
# ar_fit_weekly <- auto.arima(train_elec_cons_weekly)
# ar_fit_monthly <- auto.arima(train_elec_cons_monthly)

ar_fit_daily <- Arima(train_elec_cons_daily, order = c(1, 0, 1), seasonal = list(order = c(1, 0, 1), period = 7))
ar_fit_weekly <- Arima(train_elec_cons_weekly, order = c(1, 0, 1), seasonal = list(order = c(1, 0, 1), period = 52), method = 'CSS')
ar_fit_monthly <- Arima(train_elec_cons_monthly, order = c(1, 0, 1), seasonal = list(order = c(1, 0, 1), period = 12), )

h_daily <- nrow(test_set_daily)
h_weekly <- nrow(test_set_weekly)
h_monthly <- nrow(test_set_monthly)

ar_forecast_daily <- forecast(ar_fit_daily, h = h_daily)
ar_forecast_weekly <- forecast(ar_fit_weekly, h = h_weekly)
ar_forecast_monthly <- forecast(ar_fit_monthly, h = h_monthly)

forecast_dates_daily <- seq.Date(from = as.Date(train_test_split_date) + 1, by = "day", length.out = h_daily)
forecast_dates_weekly <- seq.Date(from = as.Date(train_test_split_date) + 1, by = "week", length.out = h_weekly)
forecast_dates_monthly <- seq.Date(from = as.Date(train_test_split_date) + 1, by = "month", length.out = h_monthly)

combined_data_daily <- data.frame(
  date = c(train_set_daily$date, forecast_dates_daily),
  Consumption = c(train_set_daily$Consumption, rep(NA, h_daily)),
  Forecast = c(rep(NA, nrow(train_set_daily)), ar_forecast_daily$mean),
  Lower_80 = c(rep(NA, nrow(train_set_daily)), ar_forecast_daily$lower[,1]),
  Upper_80 = c(rep(NA, nrow(train_set_daily)), ar_forecast_daily$upper[,1]),
  Lower_95 = c(rep(NA, nrow(train_set_daily)), ar_forecast_daily$lower[,2]),
  Upper_95 = c(rep(NA, nrow(train_set_daily)), ar_forecast_daily$upper[,2])
)

combined_data_weekly <- data.frame(
  date = c(train_set_weekly$week, forecast_dates_weekly),
  Consumption = c(train_set_weekly$Consumption, rep(NA, h_weekly)),
  Forecast = c(rep(NA, nrow(train_set_weekly)), ar_forecast_weekly$mean),
  Lower_80 = c(rep(NA, nrow(train_set_weekly)), ar_forecast_weekly$lower[,1]),
  Upper_80 = c(rep(NA, nrow(train_set_weekly)), ar_forecast_weekly$upper[,1]),
  Lower_95 = c(rep(NA, nrow(train_set_weekly)), ar_forecast_weekly$lower[,2]),
  Upper_95 = c(rep(NA, nrow(train_set_weekly)), ar_forecast_weekly$upper[,2])
)

combined_data_monthly <- data.frame(
  date = c(train_set_monthly$month, forecast_dates_monthly),
  Consumption = c(train_set_monthly$Consumption, rep(NA, h_monthly)),
  Forecast = c(rep(NA, nrow(train_set_monthly)), ar_forecast_monthly$mean),
  Lower_80 = c(rep(NA, nrow(train_set_monthly)), ar_forecast_monthly$lower[,1]),
  Upper_80 = c(rep(NA, nrow(train_set_monthly)), ar_forecast_monthly$upper[,1]),
  Lower_95 = c(rep(NA, nrow(train_set_monthly)), ar_forecast_monthly$lower[,2]),
  Upper_95 = c(rep(NA, nrow(train_set_monthly)), ar_forecast_monthly$upper[,2])
)

# Create plotly objects from ggplot for each time unit
create_plotly <- function(data, title) {
  ggplot(data, aes(x = date)) +
    geom_line(aes(y = Consumption, color = "Original Data"), size = 1) +
    geom_line(aes(y = Forecast, color = "Forecast"), size = 1) +
    geom_ribbon(aes(ymin = Lower_80, ymax = Upper_80), fill = "gray80", alpha = 0.5) +
    geom_ribbon(aes(ymin = Lower_95, ymax = Upper_95), fill = "gray60", alpha = 0.3) +
    labs(title = title,
         x = "Date",
         y = "Consumption (MW)") +
    scale_color_manual(name = "Legend", values = c("Original Data" = "black", "Forecast" = "red")) +
    theme_minimal()
}

plot_daily <- ggplotly(create_plotly(combined_data_daily, "Electricity Consumption Forecast - Daily"))
plot_weekly <- ggplotly(create_plotly(combined_data_weekly, "Electricity Consumption Forecast - Weekly"))
plot_monthly <- ggplotly(create_plotly(combined_data_monthly, "Electricity Consumption Forecast - Monthly"))
plot_monthly
plot_daily
plot_weekly


#########################################
library(shiny)

# Define UI for application
ui <- fluidPage(
  
  # Application title
  titlePanel("Electricity Consumption Forecast - SARIMA"),
  
  # Dropdown menu to select plot type
  sidebarLayout(
    sidebarPanel(
      selectInput("plot_type", label = "Select Plot Type:",
                  choices = c("Daily", "Weekly", "Monthly"),
                  selected = "Daily")
    ),
    mainPanel(
      plotlyOutput("plot")
    )
  )
)

# Define server logic
server <- function(input, output) {
  
  # Function to create plot based on selected type
  create_plot <- function(type) {
    switch(type,
           "Daily" = plot_daily,
           "Weekly" = plot_weekly,
           "Monthly" = plot_monthly)
  }
  
  # Render the plot based on selected type
  output$plot <- renderPlotly({
    plot_type <- input$plot_type
    create_plot(plot_type)
  })
}

plot_weekly

# Run the application
shinyApp(ui = ui, server = server)

#############################################

#saveWidget(plot_daily, file = "~/Downloads/ADSP_31006_FinalProject/plot_daily.html")
#saveWidget(plot_weekly, file = "~/Downloads/ADSP_31006_FinalProject/plot_weekly.html")
#saveWidget(plot_monthly, file = "~/Downloads/ADSP_31006_FinalProject/plot_monthly.html")

############################# Intervention Analysis ############################

time.points=seq.Date(as.Date("2019-01-01"),by=1, length.out =535)
#consumption=ts('Consumption')

consumption <- ts(elec_data_clean$Consumption, frequency = 365)

data_intervention=zoo(consumption, time.points)
pre.period=as.Date(c("2019-01-01", "2020-03-24"))
post.period=as.Date(c("2020-03-25","2024-03-31"))

effect = CausalImpact(data_intervention, pre.period, post.period)

plot(effect)
summary(effect)

