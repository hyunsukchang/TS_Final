# Performs initial data cleaning and analysis for energy consumption time series final project.

library(tseries)
library(performance)
library(dplyr)
library(lubridate)
library(zoo)
library(xts)
library(ggplot2)
library(outliers)
library(forecast)
par(mar=c(5.1, 4.1, 4.1, 2.1))


# import
path_to_file <- list.files(path = "~/Downloads", pattern = "electricityConsumptionAndProductioction.csv", full.names = TRUE)

elec_data <- read.csv(path_to_file)
elec_data$DateTime <- ymd_hms(elec_data$DateTime) 


# Plotting electricity consumption
plot(elec_data[["Consumption"]], type = "l", main = "Consumption", xlab = NULL, ylab = "MW", col = "red", lwd = 2)
## There is seasonality 


# Convert DateTime column to POSIXct type
elec_data$DateTime <- as.POSIXct(elec_data$DateTime)

# Subset the data for the specified date range
subset_data <- subset(elec_data, DateTime >= as.POSIXct("2023-03-01 00:00:00") & DateTime <= as.POSIXct("2023-03-08 23:59:59"))

# Plot the subset of data
plot(subset_data$DateTime, subset_data$Consumption, type = "l", main = "Weekly Consumption", xlab = NULL, ylab = "MW", col = "orange", lwd = 2)


### There is Seasonality


# Convert DateTime column to POSIXct type
elec_data$DateTime <- as.POSIXct(elec_data$DateTime)

# Subset the data for the specified date range
subset_data <- subset(elec_data, DateTime >= as.POSIXct("2023-03-01 00:00:00") & DateTime <= as.POSIXct("2023-03-01 23:59:59"))

# Plot the subset of data
plot(subset_data$DateTime, subset_data$Consumption, type = "l", main = "Daily Consumption", xlab = "Hour", ylab = "MW", col = "blue", lwd = 2)


# Plot the ACF of the consumption data
acf(elec_data$Consumption, main = "ACF Plot of Consumption Data")

# Perform first differencing on the consumption data
consumption_diff <- diff(elec_data$Consumption, differences = 1)

# Append a missing value to the differenced series
consumption_diff <- c(NA, consumption_diff)

# Assign the differenced series to the dataframe
elec_data$Consumption_diff <- consumption_diff

# Remove missing values from the differenced consumption data
cleaned_diff <- na.omit(elec_data$Consumption_diff)

# Plot the ACF of the cleaned differenced consumption data
acf(cleaned_diff, main = "ACF Plot of First Differenced Consumption Data")


#### Try first differencing to improve stationarity

#### The alternating pattern is consistent and periodic, which indicates a meaningful pattern (seasonality).





#### Now, let's try more tests to see stationarity or not.


# Augmented Dickey-Fuller (ADF) Test
adf_test <- adf.test(elec_data$Coal)
adf_test


#### Small p-values can result from large sample sizes. In contrast, visual inspection of plots may reveal subtle patterns or trends that are not captured by hypothesis tests, especially when dealing with noisy data.




## Plotting different Production types to spot trends 


# Get the column names of elec_data dataframe
Types <- names(elec_data)

# Remove the first two elements from the list
Types <- Types[-c(1, 2, 3,11, 12, 13, 14)]

Types




# Define colors corresponding to each type
colors <- c(Nuclear = 'red', Wind = 'purple', Hydroelectric = 'blue', Oil.and.Gas = 'darkgreen', Coal = 'black', Solar = 'yellow', Biomass = 'green')

# Loop over each type and plot
for (prType in Types) {
    # Create a new plot for each type
    plot(elec_data$DateTime, elec_data[[prType]], type = "l", col = colors[prType],
         main = paste(prType, "Production over Time"),
         xlab = "Date", ylab = "MW")
}



