# Load necessary libraries
library(dplyr)
library(lubridate)
library(forecast)
library(ggplot2)


# Load the data
path_to_file <- list.files(path = "~/Downloads", pattern = "electricityConsumptionAndProductioction.csv", full.names = TRUE)
data <- read.csv(path_to_file)

# Select the 'DateTime' and 'Consumption' columns and rename them to 'ds' and 'y'
energy_df <- data %>% select(ds, y)


# Define the date range for the test set
test_start_date <- as.POSIXct("2023-03-31")
test_end_date <- as.POSIXct("2024-03-31")

# Split the data into train and test sets
train_df <- dplyr::filter(energy_df, ds < test_start_date)
test_df <- dplyr::filter(energy_df, ds >= test_start_date & ds <= test_end_date)


# Convert the training set to a time series object with appropriate seasonality
y_train <- msts(train_df$y, seasonal.periods = c(365*24))  # yearly seasonality


# Fit the TBATS model with annual seasonality
tbats_model_1 <- tbats(y_train)


# Generate forecasts using the TBATS model
y_pred <- forecast(tbats_model_1, h = nrow(test_df))
plot(y_pred, ylab = "Consumption (MW)")


# Plot the components
par(mfrow = c(3, 1))
plot(trend_component, main = "Trend Component", ylab = "Trend")
plot(seasonal_component, main = "Seasonal Component", ylab = "Seasonality")
plot(remainder_component, main = "Remainder Component", ylab = "Remainder")

# Extract the forecasted values
forecast_values <- as.numeric(y_pred$mean)

# Create a dataframe with dates from test_df and corresponding forecasted values
forecast_df <- data.frame(ds = test_df$ds, y = forecast_values)

# Convert ds column in forecast_df to Date format
forecast_df$ds <- as.Date(forecast_df$ds)

# Plot only the forecasted values
ggplot() +
    geom_line(data = forecast_df, aes(x = ds, y = y), color = "black", size = 1.5) +
    labs(title = "Electricity Consumption Forecast Plot", x = "Date", y = "Consumption") +
    theme_minimal() +
    theme(
        plot.background = element_blank(),  # Remove plot background
        panel.grid.major = element_blank(),  # Remove major gridlines
        panel.grid.minor = element_blank(),  # Remove minor gridlines
        axis.line = element_line(colour = "black"),  # Set axis lines color
        aspect.ratio = 1/3  # Adjust aspect ratio to make the plot longer
    )

# Filter the forecast dataframe to align with the dates in test_df
forecast_aligned <- forecast_df[forecast_df$ds %in% test_df$ds, ]

# Convert ds column in forecast_aligned to Date format
forecast_aligned$ds <- as.Date(forecast_aligned$ds)


# Plot historical data and aligned forecast with thicker line for forecast
ggplot() +
    geom_line(data = energy_df, aes(x = ds, y = y, color = "Historical Data"), size = 1) +
    geom_line(data = forecast_aligned, aes(x = ds, y = y, color = "Forecasted Data"), size = 1.5) +
    labs(title = "Electricity Consumption Forecast Plot", x = "Date", y = "Consumption", color = "Data Type") +
    theme_minimal() +
    scale_color_manual(values = c("blue", "black")) +  # Set color values manually
    guides(color = guide_legend(title = NULL)) +  # Remove legend title
    theme(
        plot.background = element_blank(),  # Remove plot background
        panel.grid.major = element_blank(),  # Remove major gridlines
        panel.grid.minor = element_blank(),  # Remove minor gridlines
        axis.line = element_line(colour = "black"),  # Set axis lines color
        aspect.ratio = 1/3  # Adjust aspect ratio to make the plot longer
    )


# Extract components from the forecast
components <- tbats.components(tbats_model)
plot(components)





# Generate forecasts using the TBATS model
y_pred <- forecast(tbats_model, h = nrow(test_df))


# Extract the forecasted values
forecast_values <- as.numeric(y_pred$mean)

# Create a dataframe with dates from test_df and corresponding forecasted values
forecast_df <- data.frame(ds = test_df$ds, y = forecast_values)


# Filter the forecast dataframe to align with the dates in test_df
forecast_aligned <- forecast_df[forecast_df$ds %in% test_df$ds, ]

# Convert ds column in forecast_aligned to Date format
forecast_aligned$ds <- as.Date(forecast_aligned$ds)




# Plot the forecast
autoplot(y_pred) +
    autolayer(test_df, series = "Actual", PI = FALSE) +
    ggtitle("Baseline Holt-Winters Forecast vs Actual for American Eagle") +
    xlab("Year") +
    ylab("Baggage Complaints")

# Calculate evaluation metrics
hw_mae <- mae(ae_test, hw_forecast$mean)
hw_rmse <- rmse(ae_test, hw_forecast$mean)
hw_mape <- mean(abs((ae_test - hw_forecast$mean) / ae_test)) * 100

# Print the evaluation metrics
print(paste("Baseline Mean Absolute Error (MAE):", hw_mae))
print(paste("Baseline Root Mean Squared Error (RMSE):", hw_rmse))
print(paste("Baseline Mean Absolute Percentage Error (MAPE):", hw_mape))