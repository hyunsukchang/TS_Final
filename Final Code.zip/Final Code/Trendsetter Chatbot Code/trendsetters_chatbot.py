import openai
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from prophet.plot import plot_components_plotly
from prophet.diagnostics import cross_validation, performance_metrics
from forecasting import load_and_process_csv, get_forecast

# Set OpenAI API key
openai_api_key = "YOUR OPENAI KEY"

# Initialize OpenAI client
client = openai.OpenAI(api_key=openai_api_key)

# Function to get response from OpenAI using GPT-4 with streaming
def get_response(prompt):
    response_text = ""
    stream = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=150,
        temperature=0.9,
        stream=True,
    )
    for chunk in stream:
        if chunk.choices[0].delta.content:
            delta_content = chunk.choices[0].delta.content
            response_text += delta_content
            # Streamlit real-time update
            st.session_state['messages'][-1]["content"] += delta_content
            st.experimental_rerun()
    return response_text

# Function to handle user input and provide forecast or general response
def handle_user_input(user_input):
    forecasting_keywords = ["forecast", "next month", "next year", "performance metrics", "plot components", "holiday effects"]
    
    if any(keyword in user_input.lower() for keyword in forecasting_keywords):
        if 'model' not in st.session_state or 'forecast' not in st.session_state:
            st.session_state['messages'].append({"role": "assistant", "content": "Please upload a CSV file and process it first."})
            st.chat_message("assistant").write("Please upload a CSV file and process it first.")
            return
        
        model = st.session_state['model']
        forecast = st.session_state['forecast']
        
        if "next month" in user_input.lower():
            start_date = "2024-05-01"
            end_date = "2024-05-31"
            forecast_data = get_forecast(model, forecast, start_date, end_date)
            
            st.session_state['messages'].append({"role": "assistant", "content": "Here is the forecast for the next month."})
            st.chat_message("assistant").write("Here is the forecast for the next month.")
            
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.plot(forecast_data['ds'], forecast_data['yhat'], label='Forecast')
            ax.fill_between(forecast_data['ds'], forecast_data['yhat_lower'], forecast_data['yhat_upper'], alpha=0.2)
            plt.title('Electricity Consumption Forecast for Next Month')
            plt.xlabel('Date')
            plt.ylabel('MW')
            plt.legend()
            st.pyplot(fig)
            return
        elif "next year" in user_input.lower():
            start_date = "2024-01-01"
            end_date = "2024-12-31"
            forecast_data = get_forecast(model, forecast, start_date, end_date)
            
            st.session_state['messages'].append({"role": "assistant", "content": "Here is the forecast for the next year."})
            st.chat_message("assistant").write("Here is the forecast for the next year.")
            
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.plot(forecast_data['ds'], forecast_data['yhat'], label='Forecast')
            ax.fill_between(forecast_data['ds'], forecast_data['yhat_lower'], forecast_data['yhat_upper'], alpha=0.2)
            plt.title('Electricity Consumption Forecast for Next Year')
            plt.xlabel('Date')
            plt.ylabel('MW')
            plt.legend()
            st.pyplot(fig)
            return
        elif "performance metrics" in user_input.lower():
            df_cv = cross_validation(model, initial='730 days', period='180 days', horizon='365 days')
            df_p = performance_metrics(df_cv)
            st.write(df_p[['horizon', 'mae', 'mape', 'rmse', 'coverage']])
            st.session_state['messages'].append({"role": "assistant", "content": "Here are the performance metrics."})
            st.chat_message("assistant").write("Here are the performance metrics.")
            return
        elif "plot components" in user_input.lower():
            fig = plot_components_plotly(model, forecast)
            st.plotly_chart(fig)
            st.session_state['messages'].append({"role": "assistant", "content": "Here are the forecast components."})
            st.chat_message("assistant").write("Here are the forecast components.")
            return
        elif "holiday effects" in user_input.lower():
            holiday_names = model.train_holiday_names
            effects = {holiday: forecast[holiday].sum() for holiday in holiday_names if holiday in forecast.columns}
            st.write(pd.DataFrame(list(effects.items()), columns=['Holiday', 'Effect']))
            st.session_state['messages'].append({"role": "assistant", "content": "Here are the holiday effects."})
            st.chat_message("assistant").write("Here are the holiday effects.")
            return
    else:
        # Fallback to general ChatGPT response for non-forecasting queries
        st.session_state['messages'].append({"role": "assistant", "content": ""})
        response = get_response(user_input)
        st.session_state['messages'][-1]["content"] = response
        st.chat_message("assistant").write(response)
        return

# Streamlit app
st.title("\"Trendsetters\" Forecasting Chatbot")

# Initialize chat messages history
if "messages" not in st.session_state:
    st.session_state["messages"] = [{"role": "assistant", "content": "How can I help you?"}]

# Display the chat messages
for msg in st.session_state.messages:
    st.chat_message(msg["role"]).write(msg["content"])

# File uploader
uploaded_file = st.file_uploader("Upload your CSV file", type=["csv"])

# Fake dropdown menu for models
selected_model = st.selectbox("Select Forecasting Model", ["Prophet", "Random Forest", "TBATS", "ARIMA"])

# Process button
if uploaded_file is not None:
    if st.button("Process"):
        model, forecast = load_and_process_csv(uploaded_file)
        st.session_state['model'] = model
        st.session_state['forecast'] = forecast
        st.success("CSV file processed successfully.")

# Chat input
if prompt := st.chat_input():
    st.session_state.messages.append({"role": "user", "content": prompt})
    st.chat_message("user").write(prompt)

    # Check for forecast-related queries
    handle_user_input(prompt)