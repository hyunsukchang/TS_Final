import pandas as pd
from prophet import Prophet

# Function to load and process the CSV file
def load_and_process_csv(file_path):
    energy_data = pd.read_csv(file_path)
    energy_data['ds'] = pd.to_datetime(energy_data['DateTime'])
    energy_data.rename(columns={'Consumption': 'y'}, inplace=True)

    # Initialize and fit the Prophet model
    model = Prophet(seasonality_mode='multiplicative', yearly_seasonality=4, weekly_seasonality=False, holidays_prior_scale=1)
    model.add_country_holidays(country_name='RO')
    model.fit(energy_data)

    # Create a future dataframe
    future_dates = model.make_future_dataframe(periods=365*24, freq='H')
    forecast = model.predict(future_dates)

    return model, forecast

# Function to get forecast for a specific date range
def get_forecast(model, forecast, start_date, end_date):
    mask = (forecast['ds'] >= start_date) & (forecast['ds'] <= end_date)
    return forecast[mask][['ds', 'yhat', 'yhat_lower', 'yhat_upper']]